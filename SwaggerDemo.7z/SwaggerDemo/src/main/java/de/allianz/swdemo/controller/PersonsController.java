package de.allianz.swdemo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import de.allianz.swdemo.model.PersonenDaten;
import de.allianz.swdemo.repository.PersonenRepository;
import de.personen.services.model.Address;
import de.personen.services.model.PersonData;
import de.personen.services.model.ResponseStatus;

@Component
public class PersonsController {
	
	@Autowired
	private PersonenRepository perRepo;
	
	public ResponseEntity<ResponseStatus> addPersons(PersonData personData) {
		ResponseStatus rspStatus = new ResponseStatus();
		if (personData != null) {
			final String fullname = personData.getFirstname() + " " + personData.getFamilyname();
			rspStatus.setText(String.format("Der volle Name der neu angelegten Person heißt %s: ", fullname));
			
			PersonenDaten person = new PersonenDaten();
			person.setFirstName(personData.getFirstname());
			person.setFamilyName(personData.getFamilyname());
			person.setStreet(personData.getAdresse().getStreetname());
			person.setHouseNumber(personData.getAdresse().getHousenumber());
			person.setPlz(personData.getAdresse().getPostleitzahl());
			person.setCity(personData.getAdresse().getCity());
			
			System.out.println("vor dem speichern");
			perRepo.save(person);
			
			rspStatus.setUserId(person.getId().toString());
			return new ResponseEntity<ResponseStatus>(rspStatus, HttpStatus.CREATED);
		}
		rspStatus.setText("personData ist null");
		return new ResponseEntity<ResponseStatus>(rspStatus, HttpStatus.BAD_REQUEST);
		
	}

	public ResponseEntity<?> getPerson(String personId) {
		System.out.println("PersonsController.getPerson"); 
		try { 
			Optional<PersonenDaten> personOptional = perRepo.findById(Long.parseLong(personId));
			if (personOptional.isPresent()) {
				PersonData rspPerson = new PersonData();
				PersonenDaten person = personOptional.get();
				rspPerson.setFamilyname(person.getFamilyName());
				rspPerson.setFirstname(person.getFirstName());
				Address address = new Address();
				address.setStreetname(person.getCity());
				address.setHousenumber(person.getHouseNumber());
				address.setPostleitzahl(person.getPlz());
				address.setCity(person.getCity());
				
				rspPerson.setAdresse(address);
				return new ResponseEntity<PersonData>(rspPerson, HttpStatus.OK);
			}
			
		} catch (IllegalArgumentException ex) {
			System.out.println("getPerson Error: " + ex.getMessage());
		}
		ResponseStatus rspStatus = new ResponseStatus();
		rspStatus.setText("Person konnte nicht mit der ID " + personId + " nicht gefunden werden");
		return new ResponseEntity<ResponseStatus>(rspStatus, HttpStatus.BAD_REQUEST);
	}

}
