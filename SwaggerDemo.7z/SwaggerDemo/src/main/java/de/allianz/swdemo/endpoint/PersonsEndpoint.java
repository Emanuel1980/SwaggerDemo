package de.allianz.swdemo.endpoint;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.NativeWebRequest;

import de.allianz.swdemo.controller.PersonsController;
import de.personen.services.api.PersonsApiController;
import de.personen.services.model.PersonData;
import de.personen.services.model.ResponseStatus;
import io.swagger.annotations.ApiParam;

@RestController
public class PersonsEndpoint extends PersonsApiController {

	@Autowired
	private PersonsController personsController;
	
	public PersonsEndpoint(NativeWebRequest request) {
		super(request);
	}
	
	@Override
	public ResponseEntity<ResponseStatus> personsPost(@ApiParam(value = ""  )  @Valid @RequestBody PersonData personData) {
		System.out.println("persons Post");
		return (ResponseEntity<ResponseStatus>) personsController.addPersons(personData);
		
	}
	
	@Override
	public ResponseEntity<PersonData> personsPersonIdGet(@ApiParam(value = "",required=true) @PathVariable("personId") String personId) {
		System.out.println("persons Get");
		return (ResponseEntity<PersonData>) personsController.getPerson(personId);
	}

}
